     
        <!---footer section-->
        <section id="footer">
          <img src="wave-footer.png" class="footer-img">
          

        </section>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!-- JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>

</html>

      <!-- Bootstrap core JavaScript-->
      <script src="../vendor/jquery-3.4.1.min.js"></script>
      <script src="../vendor/bootstrap/popper.min.js"></script>
      <script src="../vendor/bootstrap/bootstrap.min.js"></script>

      <!-- Core plugin JavaScript-->
      <script src="../vendor/datatables/jquery.dataTables.js"></script>
      <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

      <!-- Page level plugin JavaScript-->
      <script src="../vendor/chart.js/Chart.min.js"></script>
    </body>

</html>