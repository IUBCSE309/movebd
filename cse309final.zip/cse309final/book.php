<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="asset/css/style.css">
   <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
     
  <section id="nav-bar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="index.php" class="color:white">MoveBD</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.html">Login</a>
                    </li>
                </ul>
            </div>
        </nav>
    </section>
    <!---using breaks--->
    <br>
    <br>
    <br>
    <br>
    <br>
      <!----order---section---->
    <section>
        
<!------ Include the above in your HEAD tag ---------->

 <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="well-block">
                        <div class="well-title">
                            <h2>GET A QUOTATION:</h2>
                        </div>
                        
                            <!-- Form start -->
                            <form id="book-form" name="book-form" action="insert2.php" method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="name">Name</label>
                                        <input id="name" name="name" type="text" class="form-control input-md">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="email">Email</label>
                                        <input id="email" name="email" type="text"  class="form-control input-md">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="from">FROM</label>
                                        <input id="From" name="from" type="text" class="form-control input-md">
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label" for="to">TO</label>
                                        <input id="TO" name="to" type="text" class="form-control input-md">
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label" for="address">ADDRESS</label>
                                        <input id="address" name="address" type="text" class="form-control input-md">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="time">Preferred Time</label>
                                        <select id="time" name="time" class="form-control">
                                            <option value="8:00 to 9:00">8:00 to 9:00</option>
                                            <option value="9:00 to 10:00">9:00 to 10:00</option>
                                            <option value="10:00 to 1:00">10:00 to 1:00</option>
                                            <option value="10:00 to 1:00">1:00 to 4:00</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label" for="appointmentfor">Book for</label>
                                        <select id="appointmentfor" name="appointmentfor" class="form-control">
                                            <option value="Service#1">Home Shifting</option>
                                            <option value="Service#2">Relocation</option>
                                            <option value="Service#3">Office Shifting</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Button -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button id="singlebutton" name="singlebutton" class="btn btn-default">BOOK NOW</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!-- form end -->
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="well-block">
                        <div class="well-title">
                            <h2>Book Our Services</h2>
                        </div>
                        <div class="feature-block">
                            <div class="feature feature-blurb-text">
                                <h4 class="feature-title">Available 7 Days a Week</h4>
                            </div>
                            <div class="feature feature-blurb-text">
                                <h4 class="feature-title">Experienced Staff</h4>
                            </div>
                            <div class="feature feature-blurb-text">
                                <h4 class="feature-title">Low Price & Fees</h4>
                                <</div>
                                </div>
    </section>


<!--Social Media-->
    <section id="social-media">
        <div class="container text-center">
            <p>FIND US ON SOCIAL MEDIA</p>
            <div class="social-icons">
                <a href="#"><img src="images/facebook.png"></a>
                <a href="#"><img src="images/instagram.png"></a>
                <a href="#"><img src="images/whatsapp.png"></a>
                <a href="#"><img src="images/twitter.png"></a>
                </div>
            <div class="container text-center">
          <small>Developed by <a class="text-black"target="_blank"> Ahmed Seeam Nurullah</a> | CSE309-2020</small>
        </div>
        </div>
    </section>
    <!---footer section-->
    <section id="footer">
        <img src="wave-footer.png" class="footer-img">


    </section>


</body>
</html>





  

  