<!DOCTYPE html>
<html lang="en">
  <html>
    <head>
        <title>
            MoveBD
        </title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!-- JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <section id="nav-bar">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <!--<a class="navbar-brand" href="#">MoveBD</a>-->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                  <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                      <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="Book.php">Book Now</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="login.html">Login</a>
                    </li>
                  </ul>
                </div>
              </nav>
        </section>
          <!---------------banner section---------------------------->

          <section id="banner">
            <div class="container">
            <div class="row">
                <div class="col-md-6">
                <p class="promo-title">MoveBD</p>
                <p>GET MOVING!</p>
                <a href="#services"><img src="images/eye.png" class="view-btn"></a>View Services
                </div>
                <div class="col-md-6 text-center">
                  <img src="images/movers.jpg" class="img-fluid">

                </div>
            </div>
            </div>
          <!--  <img src="25101.jpg" class="bottom-img">-->
        </section>
    
        <!-----services section-->
        <section id="services">
          <div class="container text-center">
            <h1 class="title">OUR SERVICES</h1>
            <div class="row text-center">
              <div class="col-md-4 services">
                <img src="images/flat.png" class="img-fluid">
                <h4>Residential Move</h4>
                <p>We facilitate residential move services with utmost care and priority! </p>
              </div>
              <div class="col-md-4 services">
                <img src="images/corporation.png" class="img-fluid">
                <h4>Corporate Relocation</h4>
                <p> We facilitate Office Packing & Relocation services.</p>
              </div>
              <div class="col-md-4 services">
                <img src="images/oil-bottle.png" class="img-fluid">
                <h4>Industrial Moves</h4>
                <p>We have expertise in handling of Machineries & Equipment</p>
              </div>
            </div>
            <button type="button" class="btn btn-primary">All Services</button>
          </div>
        </section>
        <!---About Us-->
        <section id="about-us">
          <div class="container">
            <h1 class="title text-center"> WHY CHOOSE US?</h1>
            <div class="row">
              <div class="col-md-6 about-us"></div>
              <!--<p class="about-title">Why we're different</p>-->
                <!--using container to create space between sections-->
                <div class="container pt-5"></div>
                <!--ending the spaces here-->
                <ul class>
                  <li>Attention to Details</li>
                  <li>Experts Only</li>
                  <li>Reasonable Pricing</li>
                  <li>Meet Deadlines</li> 
                </ul>
            </div>
            </div>
        </section>
        <!-----testimonials-->
        <section id="Testimonials">
          <h1 class="title text-center"> WHAT CLIENTS SAY?</h1>
          <div class="row offset-1">
            <div class="col-md-4 testimonials">
              <p>Moving and shifting is a hectic! . When we were relocating, MoveBD really eased our operations and the shifting went really smooth.</p>
              <img src="images/user.png" alt="">
              <p><b>Sufia Begum</b> <br>Homemaker
              </p>
            </div>
            <div class="col-md-4 testimonials">
              <p> My job requires me to move a lot. I have been using services provided by MoveBD for a while now. They never dissapoint!.</p>
              <img src="images/user.png" alt="">
              <p><b>Samiur Hoque</b> <br> Police Officer 
              </p>
            </div>
            <div class="col-md-4 testimonials">
              <p>While shifting into my new office, we got in contact with MoveBD. They have catered to all our needs with utmost sincerity</p>
              <img src="images/user.png" alt="">
              <p><b>Zubair Shahjahan</b> <br> Manager at WIPRO ltd
              </p>
            </div>
          </div>
        </section>
        <!--Social Media-->
        <section id="social-media">
          <div class="container text-center">
          <p>FIND US ON SOCIAL MEDIA</p>
          <div class="social-icons">
            <a href="#"><img src="images/facebook.png" ></a>
            <a href="#"><img src="images/instagram.png" ></a>
            <a href="#"><img src="images/whatsapp.png" ></a>
            <a href="#"><img src="images/twitter.png" ></a>
          </div>
          <div class="container text-center">
          <small>Developed by <a class="text-black"target="_blank">Ahmed Seeam Nurullah</a> | 2020</small>
        </div>
        </div>
        </section>
        <!---footer section-->
        <section id="footer">
          <img src="images/wave-footer.png" class="footer-img">
          

        </section>

        
    </body>
</html>