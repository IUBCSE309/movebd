<?php

    $name=$_POST{'name'};
    $email=$_POST{'email'};
    $fromw=$_POST{'fromw'};
    $tow=$_POST{'tow'};
    $address=$_POST{'address'};

    $link = mysqli_connect("localhost","root","","movebd");

    if($link===false){
        die("ERROR: could not connect. " . mysqli_connect_error());
    }
    $sql = "INSERT INTO booktb(name, email, fromw, tow, address) VALUES ('$name','$email','$fromw','$tow','$address')";
        if(mysqli_query($link, $sql)){
                header("location:index.php");
                exit;
        }
        else{
            echo"ERROR: Could not execute $sql.". mysqli_error($link);
        }
        mysqli_close($link);

?>
