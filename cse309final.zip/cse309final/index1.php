<?php include('include/header.php'); ?>

  <div class="jumbotron jumbotron-fluid">
    <div class="container">
        <h1 class="display-4">Hello!</h1>
        <p class="display-4"><?php echo $_SESSION['fullname']; ?></p>
        <hr class="my-4">
        <h1 class="display-4">To Schedule a service</h1>
      <a class="btn btn-light btn-lg" target="blank" href="book.php" role="button">Click Here</a>
    </div>
  </div>

<?php include('include/footer.php'); ?>