<?php

    $name=$_POST{'name'};
    $email=$_POST{'email'};
    $subject=$_POST{'subject'};
    $message=$_POST{'message'};
    echo $name;

    $link = mysqli_connect("localhost","root","","movebd");

    if($link===false){
        die("ERROR: could not connect. " . mysqli_connect_error());
    }
    $sql = "INSERT INTO contactform(name, email, subject, message) VALUES ('$name','$email','$subject','$message')";
        if(mysqli_query($link, $sql)){
                header("location:index.php");
                exit;
        }
        else{
            echo"ERROR: Could not execute $sql.". mysqli_error($link);
        }
        mysqli_close($link);

?>
