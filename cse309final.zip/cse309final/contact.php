
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="asset/css/style.css">
   <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
     
  <section id="nav-bar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="index.php" class="color:white">Movebd</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="book.php">Book Now</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.html">Login</a>
                    </li>
                </ul>
            </div>
        </nav>
    </section>
    
     <!--contact form-->
 <div id="contactform" class="container">
        
        <section class="mb-4">
            <h2 class="h1-responsive font-weight-bold text-center-left my-4">Contact Us</h2>
        
            <div class="row">
                <div class="col-md-9 mb-md-0 mb-5">
                    <form id="contact-form" name="contact-form" action="insert.php" method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="md-form mb-0">
                                    <input type="text" id="name" name="name" class="form-control">
                                    <label for="name" class="">Name</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="md-form mb-0">
                                    <input type="text" id="email" name="email" class="form-control">
                                    <label for="email" class="">Email</label>
                                </div>
                            </div>
        
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="md-form mb-0">
                                    <input type="text" id="subject" name="subject" class="form-control">
                                    <label for="subject" class="">Subject</label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
        
                                <div class="md-form">
                                    <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>
                                    <label for="message">Message</label>
                                </div>
        
                            </div>
                        </div>
                    </form>
        
                    <div class="text-center text-md-left">
                        <a class="btn btn-light" onclick="document.getElementById('contact-form').submit();">Send</a>
                    </div>
                    <div class="status"></div>
                </div>
                <!-----------using breaks---->
                <br>
                <br>
                <br>
                <div class="col-md-3 text-center">
                    <ul class="list-unstyled mb-0">
                        <li><i class="fas fa-map-marker-alt fa-2x"></i>
                        <h4 class="feature-title">House 7/10, Block B, Lalmatia, Dhaka</h4>
                        </li>
        
                        <li><i class="fas fa-phone mt-4 fa-2x"></i>
                        <h4 class="feature-title">+880 1748388487</h4>
                            
                        </li>
        
                        <li><i class="fas fa-envelope mt-4 fa-2x"></i>
                        <h4 class="feature-title">movebd@gmail.com</h4>
                        </li>
                    </ul>
                </div>
        
            </div>
        
        </section>
      
<!--Social Media-->
    <section class="container text-center"id="social-media">
        <div class="container text-center">
            <p>FIND US ON SOCIAL MEDIA</p>
            <div class="social-icons">
                <a href="#"><img src="images/facebook.png"></a>
                <a href="#"><img src="images/instagram.png"></a>
                <a href="#"><img src="images/whatsapp.png"></a>
                <a href="#"><img src="images/twitter.png"></a>
                </div>
            <div class="container text-center">
          <small>Developed by <a class="text-black"target="_blank"> Ahmed Seeam Nurullah</a> | CSE309-2020</small>
        </div>
        </div>
    </section>
   

</body>
</html>





  

  