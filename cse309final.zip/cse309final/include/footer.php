        <!--Social Media-->
        <section id="social-media">
          <div class="container text-center">
          <p>FIND US ON SOCIAL MEDIA</p>
          <div class="social-icons">
            <a href="#"><img src="images/facebook (1).png" ></a>
            <a href="#"><img src="images/facebook (1).png" ></a>
            <a href="#"><img src="images/facebook (1).png" ></a>
            <a href="#"><img src="images/facebook (1).png" ></a>
          </div>
          <div class="container text-center">
          <small>Developed by <a class="text-black"target="_blank">Ahmed Seeam Nurullah</a> | CSE309-2020</small>
        </div>
        </div>
        </section>
        <!---footer section-->
        <section id="footer">
          <img src="wave-footer.png" class="footer-img">
          

        </section>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!-- JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  </body>

</html>